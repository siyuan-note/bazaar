# sy-excalidraw
思源的Excalidraw挂件

# 使用步骤

1. 插入挂件
2. 调整大小
3. 点击右上角保存按钮
4. 关闭标签页
