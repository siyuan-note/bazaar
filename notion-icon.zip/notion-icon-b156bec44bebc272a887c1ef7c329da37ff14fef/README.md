# notion-icon
![preview](https://raw.githubusercontent.com/royc01/notion-icon/main/preview.png)
