# 思源笔记亮色主题：Winter

此主题已停止更新，新的主题已统一迁移至 [Toy Theme for Siyuan](https://github.com/langzhou/toy-theme-for-siyuan) 


![preview](https://raw.githubusercontent.com/langzhou/winter-theme-for-siyuan/main/preview.png)
