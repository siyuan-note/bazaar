# Clock-Pac

The name is commbined with Clock and Pac-man.
It will display date today and time now,with a progressing bar.
Preview: https://achuan-2.github.io/siyuan-widget-clockpac/
![](preview.png)
