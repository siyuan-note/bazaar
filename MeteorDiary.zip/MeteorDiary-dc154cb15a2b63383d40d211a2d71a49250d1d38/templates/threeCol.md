
{{{col
{{{
### ✨ fisrt
{: style="color: var(--b3-card-error-color);background-color: var(--b3-card-error-background);"}
- text

}}}

{{{
### 🎉 second
{: style="color: var(--b3-card-info-color);background-color: var(--b3-card-info-background);"}
- text
}}}

{{{
### ✏ three
{: style="color: var(--b3-card-success-color);background-color: var(--b3-card-success-background);"}
- text

}}}

}}}
