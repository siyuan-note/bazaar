
## 🧱 Todo List

{{{col
{{{
### 📅 Upcoming
{: style="color: var(--b3-card-error-color);background-color: var(--b3-card-error-background);"}
- todo1

}}}

{{{
### ⛅️ Tomorrow
{: style="color: var(--b3-card-info-color);background-color: var(--b3-card-info-background);"}
- [ ] todo3
}}}

{{{
### ☀️ Today
{: style="color: var(--b3-card-success-color);background-color: var(--b3-card-success-background);"}
- [ ] todo5

}}}

{{{
### ✅ Done 
{: style="color: var(--b3-card-warning-color);background-color: var(--b3-card-warning-background);"}
- [x] todo7

}}}
}}}
