# Golden-Topaz-Refined-Siyuan
A ported Golen Topaz theme for Siyuan note with tweaks and serif focused.

The original Golen Topaz Theme for Obsidian: https://github.com/shaggyfeng/obsidian-Golden-Topaz-theme

The theme mainly uses Source Sans / Source Han Sans (Pan-CJK support) as sans serif font, and Sourc Serif / Source Han Serif (Pan-CJK support) as serif font. You could install it form

Serif
- https://source.typekit.com/source-han-serif/
- https://github.com/adobe-fonts/source-serif

Sans Serif
- https://github.com/adobe-fonts/source-han-sans
- https://github.com/adobe-fonts/source-sans

With the use of super block, it support psuedo admonition style blocks.
## Preview
![Preview](https://github.com/roeseth/Siyuan-Golden-Topaz-Refined/blob/main/preview.png)
