# 思源笔记 Relue-dark 主题
在思源笔记原 midnight 主题的基础上增加红、蓝两种颜色，使相关元素的显示更为突出。

![img](https://github.com/Sanly/Relue-dark/blob/main/screenshot/Relue-dark.png?raw=true)
