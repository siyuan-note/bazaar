# 更改日志/CHANGE LOG

## v0.1.3/2021-11-09

- 更新 Brython 版本至 [3.10.3](https://github.com/brython-dev/brython/releases/tag/3.10.3) / Update Brython version to [3.10.3](https://github.com/brython-dev/brython/releases/tag/3.10.3).

## v0.1.2/2021-10-26

- 将挂件名称更改为 `brython-console` / Change the widget name to `brython-console`.
- 取消控制台面板的拼写检查 / Cancel spell checking for the console panel.
- 更新预览图片 / Update the preview picture.

## v0.1.1/2021-10-23

- 添加 python 中 `help` 函数依赖文件 / Add the dependent file of `help` function in python.

## v0.1.0/2021-10-19

- 新建项目 / Create a new project.
- 添加 `亮色`与 `暗色`种主题与主题切换开关 / Add a theme switch for `Light` and `Dark` themes.
