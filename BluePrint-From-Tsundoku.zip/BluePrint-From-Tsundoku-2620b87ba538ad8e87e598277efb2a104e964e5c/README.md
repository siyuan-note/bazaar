# BluePrint-From-Tsundoku
![preview](https://user-images.githubusercontent.com/48144208/134294496-a2b5e337-49af-49b9-8e5d-224b974adc83.png)

- Theme For Siyuan Note
- inspired by [Tsundoku]https://github.com/Achuan-2/siyuan-themes-tsundoku-light
- 因为大佬自己的推荐码已经完成指标了，欢迎使用我的推荐码 weYMXFD

