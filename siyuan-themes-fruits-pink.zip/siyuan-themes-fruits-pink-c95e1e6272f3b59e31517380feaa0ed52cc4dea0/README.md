# siyuan-themes-fruits-pink
this is a pink theme for siyuan
## preview
![preview](./preview.png)
