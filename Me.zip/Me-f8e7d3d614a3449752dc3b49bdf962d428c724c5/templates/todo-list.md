
## ⛵️ Todo List

{{{col

{{{

### ⛅️ Todo
{: style="color: var(--b3-card-info-color);background-color: var(--b3-card-info-background);"}
- [ ] todo3
}}}

{{{
### ☀️ Doing
{: style="color: var(--b3-card-success-color);background-color: var(--b3-card-success-background);"}
- [ ] todo5

}}}

{{{
### 🍔 Done 
{: style="color: var(--b3-card-warning-color);background-color: var(--b3-card-warning-background);"}
- [x] todo7

}}}
}}}
