.action{(now | date_modify "168h") | date "2006-01-02"}

