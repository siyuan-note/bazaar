# Tsundoku icon
 a icon repository for [SiYuan](https://github.com/siyuan-note), which is adapted from the material icon.
 I only change two icons so far:
 - iconFile
 - iconFilesRoot

 ![preview.png](preview.png)
