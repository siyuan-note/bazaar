# notion-dark复刻版
适用版本：思源笔记 v1.2.6 
需要搭配复刻图标使用：https://github.com/royc01/notion-icon
![preview](https://raw.githubusercontent.com/royc01/notion-dark/main/preview.png)
*********
调整结构，与明亮版一致
*********
修正自定义图标
修正边栏被压缩问题
*********
