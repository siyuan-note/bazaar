# Siyuan Template Notion-Cover

- 参考[Meteor](https://github.com/zhangjl-sjtu/MeteorDiary)
- 调用[Lorem Picsum](https://picsum.photos)的API显示随机图片
