{{ $coverPath := nospace (cat "https://picsum.photos/id/" ((randInt 1 1083) | toString) "/1600/500")}}
{: id="20210317143205-1pz24mz" updated="20210320140634"}

<iframe src="{{$coverPath}}" scrolling="no"></iframe>

{: id="20210323215141-ppfktad" updated="20210326013201"}


{: id="20210323215213-ree2o88" type="doc"}
