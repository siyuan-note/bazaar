# 思源笔记 Relue-light 主题
在思源笔记原 daylight 主题的基础上增加红、蓝两种颜色，使相关元素的显示更为突出。

![img](https://github.com/Sanly/Relue-light/blob/main/screenshot/Relue-light.png?raw=true)
