# Blue-X
Theme for Siyuan Note

![image](https://user-images.githubusercontent.com/48144208/134467673-cf26e45c-f990-4516-88bd-148d6b45ed0a.png)
