# List query templates for SiYuan-Note without duplicate items

## Introduction
* **finditem.md**: search the <kbd>item block</kbd> without duplicate items
* **findtodo.md**: search the <kbd>todo list</kbd> without duplicate items
* **finddone.md**: search the completed <kbd>todo list</kbd> without duplicate items
